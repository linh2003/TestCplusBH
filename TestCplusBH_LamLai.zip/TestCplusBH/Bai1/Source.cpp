#include <iostream>
using namespace std;


int main(){
	int a = 3, y = 5;
	int *xPtr, x[10] = {0};
	xPtr = &x[1];
	*(xPtr + 3) = x[5] = a + y;
	cout << "x[3]=" << x[3] << endl;
	cout << "x[4]=" << x[4] << endl;
	cout << "x5]=" << x[5] << endl;

	system("pause");
	return 0;
}