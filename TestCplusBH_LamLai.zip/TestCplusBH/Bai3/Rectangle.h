#pragma once
#include "Vec2d.h"
#include "GraphicBase.h"
class Rectangle : public GraphicBase
{
public:
	Rectangle();
	Rectangle(const Vec2d&,const Vec2d&);
	void DrawLine(const Vec2d&,const Vec2d&);
};

