#pragma once
#include "Vec2d.h"
#include "GraphicBase.h"
class Polyline : public GraphicBase
{
private:
	int numVertices;
	Vec2d v;
public:
	Polyline();
	Polyline(int);
	void Vertices(int,const Vec2d&);
	void DrawLine();
};

