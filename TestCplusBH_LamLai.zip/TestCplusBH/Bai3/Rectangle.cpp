#include "Rectangle.h"


Rectangle::Rectangle()
{

}

Rectangle::Rectangle(const Vec2d& p1,const Vec2d& p2)
{
	this->DrawLine(p1,p2);
}

void Rectangle::DrawLine(const Vec2d& p1,const Vec2d& p2)
{
	cout << "Reactangle: (" << p1.x << "," << p1.y << "-" << p2.x << "," << p2.y << endl;
}



