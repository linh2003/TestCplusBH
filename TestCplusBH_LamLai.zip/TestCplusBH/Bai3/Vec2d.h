#pragma once
class Vec2d
{
public:
	int x;
	int y;
public:
	Vec2d();
	Vec2d(int,int);
};

