#include "Polyline.h"


Polyline::Polyline()
{
	numVertices = 0;
}

Polyline::Polyline(int n) : numVertices(n)
{
}

void Polyline::Vertices(int index,const Vec2d& pos)
{
	if (numVertices < index)
	{
		numVertices = index;
	}
	v = pos;
}

void Polyline::DrawLine()
{
	cout << "Polyline: (";
	for (int i = 0; i < numVertices; i++)
	{
		cout  << v.x << "," << v.y << endl;
	}
}
