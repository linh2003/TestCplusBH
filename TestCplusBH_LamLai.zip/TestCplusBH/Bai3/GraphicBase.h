#pragma once
#include <iostream>
#include "Vec2d.h"
using namespace std;

class GraphicBase
{
protected:
	Vec2d vec;
public:
	GraphicBase();
	GraphicBase(const Vec2d&);
	void DrawLine(const Vec2d&,const Vec2d&);
	
};

