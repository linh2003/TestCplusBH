#include "Vec2d.h"


Vec2d::Vec2d()
{
	x = y = 0;
}

Vec2d::Vec2d(int x,int y) : x(x),y(y)
{
}
