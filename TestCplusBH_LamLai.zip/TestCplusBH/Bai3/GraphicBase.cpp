#include "GraphicBase.h"


GraphicBase::GraphicBase()
{
}

GraphicBase::GraphicBase(const Vec2d& vec)
{
	this->vec.x = vec.x;
	this->vec.y = vec.y;
}

void GraphicBase::DrawLine(const Vec2d& P1,const Vec2d& P2)
{
	cout << "Line: (" << P1.x << "," << P1.y << "-" << P2.x << "," << P2.y << endl;
}


