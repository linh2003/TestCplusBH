#pragma once
#include <iostream>
#include <vector>
using namespace std;


class Graphic
{
private:
	template<class T>
	vector<Graphic> vec;
public:
	Graphic();
	template<class T>
	void Insert(T);
	void Draw();
};

