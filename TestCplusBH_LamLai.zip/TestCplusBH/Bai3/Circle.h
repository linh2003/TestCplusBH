#pragma once
#include "Vec2d.h"
#include "GraphicBase.h"
class Circle : public GraphicBase
{
private:
	double radius;
public:
	Circle();
	Circle(double, const Vec2d&);
	void DrawLine();
};

