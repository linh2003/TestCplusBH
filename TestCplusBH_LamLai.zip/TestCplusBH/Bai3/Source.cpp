#pragma once
#include "Rectangle.h"
#include "Circle.h"
#include "Polyline.h"
#include "Graphic.h"

int main()
{
	//Circle
	Vec2d center(10,10);
    double radius=5.0;
    Circle mCricle(radius,center);

	int numVertices=10;
    Vec2d pos;
    Polyline mPolyline(numVertices);
    for(int i=0;i<numVertices;i++)
    {
        pos.x=i;
        pos.y=i;
        mPolyline.Vertices(i,pos); 
    }

	//Rectangle
	Vec2d mLowLeft(0,0);
    Vec2d mUpperRight(10,5);
	Rectangle mRectangle(mLowLeft,mUpperRight);

	Graphic mGraphic;
    mGraphic.Insert(mCricle);
    //mGraphic.Insert(mPolyline);
    mGraphic.Insert(mRectangle);
    mGraphic.Draw();

	system("pause");
	return 0;
}