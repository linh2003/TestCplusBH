#include "Graphic.h"


Graphic::Graphic()
{
	
}

template<class T>
void GraphicBase::Insert(T obj)
{
	this->vec.push_back(obj);
}

void Graphic::Draw()
{
	for (int i = 0; i < this->vec.size(); i++)
	{
		this->vec[i].DrawLine();
	}
}
