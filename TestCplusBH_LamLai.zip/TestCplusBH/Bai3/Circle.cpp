#include "Circle.h"


Circle::Circle()
{
	radius = 0.0;
}

Circle::Circle(double r, const Vec2d& p)
{
	radius = r;
	this->vec.x = p.x;
	this->vec.y = p.y;
}

void Circle::DrawLine()
{
	cout << "Circle: (" << this->vec.x << "," << this->vec.y << "-" << radius << endl;
}


