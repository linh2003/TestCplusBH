#include <iostream>
using namespace std;


int main(){
	int a = 3, y = 5;
	int *xPtr, x[10] = {0};
	xPtr = &x[1];
	*(xPtr + 3) = x[5] = a + y;
	for (int i = 0; i < 10; i++)
	{
		cout << "x["<< i << "]=" << x[i] << endl;
	}
	cout << endl;

	system("pause");
	return 0;
}