#include <iostream>
using namespace std;

struct Node
{
	int data;
	Node *pNext;
};

//typedef struct NODE* Node;

Node *CreateNode(int number)
{
	Node *p = new Node;
	p->data = number;
	p->pNext = NULL;
	return p;
}

Node *addHead(Node *node, int number){
	Node *temp = CreateNode(number);
	if (node->pNext == NULL)
	{
		node->data = number;
	}else
	{
		node->data = number;
		node->pNext = temp;
	}
	return node;
}

Node *removeNode(Node *node){
	if (node->pNext == NULL)
	{
		return node;
	}else
	{
		node = node->pNext;
	}
}

Node *removeNodeEven(Node *node){

	for (Node *p = node;p != NULL;p = p->pNext)
	{
		if (p->data % 2 == 0)
		{
			node = removeNode(node);
		}
	}
	return node;
}

Node *sortAscNodeOdd(Node *node){
	Node *minOdd = node;
	for (Node *p = node;p != NULL;p = p->pNext)
	{
		if (p->data < minOdd->data)
		{
			int tmp = minOdd->data;
			minOdd->data = p->data;
			p->data = tmp;
		}
	}
	return node;
}

Node *initNode(){
	Node *node = NULL;
	return node;
}


void Nhap(){
	Node *node = initNode();
	cout << "Enter number:";
	int input = 0;
	do
	{
		cout << "---------- MENU ----------\n"
			<< "1.Them so vao danh sach don\n"
			<< "2.Xoa so chan khoi danh sach don\n"
			<< "3.Sap xep thu tu tang dan cua node le\n"
			<< "Chon menu:";
		cin >> input;
		if (input == 0 )
		{
			cout << "Vui long Nhap lai\n";
		}
		switch (input)
		{
		case 1:
			addHead(node,input);
			break;
		default:
			break;
		}
	} while (input != 0);
}


int main(){
	Nhap();

	system("pause");
	return 0;
}