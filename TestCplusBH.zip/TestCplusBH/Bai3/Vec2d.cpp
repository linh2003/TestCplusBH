#include "Vec2d.h"


Vec2d::Vec2d()
{
	x = y = 0;
}


