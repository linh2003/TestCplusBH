#include "GraphicBase.h"


GraphicBase::GraphicBase()
{
}

void GraphicBase::DrawLine(const Vec2d& P1,const Vec2d& P2)
{
	cout << "Line: (" << P1.x << "," << P1.y << "-" << P2.x << "," << P2.y << endl;
}

