#pragma once
#include "Vec2d.h"
#include "GraphicBase.h"
class Circle : public GraphicBase
{
public:
	Circle();
};

