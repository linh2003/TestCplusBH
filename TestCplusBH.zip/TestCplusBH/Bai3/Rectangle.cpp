#include "Rectangle.h"


Rectangle::Rectangle()
{

}

Rectangle::Rectangle(Vec2d v,int w,int h) : point(v),width(w),height(h)
{

}

void Rectangle::Draw(Vec2d p1,Vec2d p2){
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			DrawLine(p1,p2);
		}
	}
}


