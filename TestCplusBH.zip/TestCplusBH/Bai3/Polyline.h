#pragma once
#include "Vec2d.h"
#include "GraphicBase.h"
class Polyline : public GraphicBase
{
public:
	Polyline();
};

