#pragma once
#include "Vec2d.h"
#include "GraphicBase.h"
class Rectangle : public GraphicBase
{
private:
	Vec2d point;
	int height;
	int width;
public:
	Rectangle();
	Rectangle(Vec2d,int,int);
	void Draw(Vec2d,Vec2d);
};

