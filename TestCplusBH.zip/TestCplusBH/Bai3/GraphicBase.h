#pragma once
#include <iostream>
#include "Vec2d.h"
using namespace std;

class GraphicBase
{
public:
	GraphicBase();
	void DrawLine(const Vec2d&,const Vec2d&);
};

